package bookstore;

import bookstore.config.kafka.KafkaProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired OrderRepository orderRepository;

    // @StreamListener(KafkaProcessor.INPUT)
    // public void wheneverDeliveryStarted_StatusUpdate(@Payload DeliveryStarted deliveryStarted){

    //     //if(!deliveryStarted.validate()) return;

    //     System.out.println("\n\n##### listener StatusUpdate : " + deliveryStarted.toJson() + "\n\n");

    //     // Sample Logic //
    //     if (deliveryStarted.isMe()) {
    //         Order order = new Order();
    //         orderRepository.save(order);
    //     }

            
    // }
    // @StreamListener(KafkaProcessor.INPUT)
    // public void wheneverDeliveryCancelled_StatusUpdate(@Payload DeliveryCancelled deliveryCancelled){

    //     //if(!deliveryCancelled.validate()) return;

    //     System.out.println("\n\n##### listener StatusUpdate : " + deliveryCancelled.toJson() + "\n\n");

    //     if (deliveryCancelled.isMe()) {
    //         Order order = new Order();
    //         orderRepository.save(order);
    //     }
            
    // }


    @StreamListener(KafkaProcessor.INPUT)
    public void whatever(@Payload String eventString){}


}
