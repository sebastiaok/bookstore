package bookstore;

import bookstore.config.kafka.KafkaProcessor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired PayRepository payRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrderCancelled_PayCancel(@Payload OrderCancelled orderCancelled){

        System.out.println("\n\n##### listener PayCancel : " + orderCancelled.toJson() + "\n\n");

        if(!orderCancelled.validate()) return;        

        Pay pay = new Pay();
        System.out.println("\n\n##### 주문번호 : " + orderCancelled.getId() + "\n\n");
        pay.setOrderId(orderCancelled.getId());
        pay.setQty(orderCancelled.getQty());
        pay.setPrice(orderCancelled.getPrice());
        pay.setStatus(orderCancelled.getStatus());
        pay.setStatus("PayCancelled");
        
        payRepository.save(pay);    
    }


}
