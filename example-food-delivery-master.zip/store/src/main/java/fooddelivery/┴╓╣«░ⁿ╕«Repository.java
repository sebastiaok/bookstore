package fooddelivery;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface 주문관리Repository extends PagingAndSortingRepository<주문관리, Long>{


}